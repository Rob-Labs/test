require("dotenv").config();
const { Telegraf } = require("telegraf");
require("./src/models/db");
const { formatNumber, getNumber } = require("./src/helpers/get-number");
const { getRoburnaPrice, getBusdPrice, getTotalSupply } = require("./src/helpers/get-price");
const { groupCheck, isGroupAdmin, isGroupMaxTokenReached } = require("./src/middleware/group-check");

const { addToken } = require("./src/commands/add-token");
const { setEmoji } = require("./src/commands/set-emoji");
const { setMinBuy } = require("./src/commands/set-min-buy");
const { setStep } = require("./src/commands/set-step");
const { deleteToken } = require("./src/commands/delete-token");
const { handleBotKicked, handleBotAdded, handleMigrateFromChatId, handleMigrateToChatId } = require("./src/middleware/handle-update-type");

const bot = new Telegraf(process.env.BOT_TOKEN);
const botOpts = {
  parse_mode: "HTML",
  disable_web_page_preview: true,
};

bot.telegram.setMyCommands([
  {
    command: "start",
    description: "Start using bot",
  },
  {
    command: "help",
    description: "Display help",
  },
  {
    command: "price",
    description: "Get Roburna price",
  },
  {
    command: "info",
    description: "Get Information about Roburna",
  },
  {
    command: "add",
    description: "Add the the token you want me to follow (max 1 per group, must be a Pancakeswap WBNB Pair (eg: not BUSD/USDC).",
  },
  {
    command: "delete",
    description: "Delete token notifications",
  },
  {
    command: "minbuy",
    description: "Change the minimumn amount of BNB spend to trigger a buy notification, default is 0.1 BNB.",
  },
  {
    command: "step",
    description: "Change the 'step' amount, or how much BNB each dot represents. Default is 0.1 BNB (Eg: 1 BNB = 10 tree)",
  },
  {
    command: "emoji",
    description: "Change emoji, default is 🌳",
  },
]);

const helpMessage = (info) => `
Hi! I'm <a href="http://t.me/RoburnaLabs_bot">${info.first_name} Bot</a>, and these are the commands I respond to:

Price
/price
 - Get Roburna price

Info
/info
 - Get Information about Roburna

Help
/help
 - Repeat this message

<b>Group only Settings</b>

/add TOKEN_ADDRESS
 - Add the token you want me to follow (max 1 per group, must be a Pancakeswap WBNB Pair (eg: not BUSD/USDC).

/minbuy MINIMUM_BUY_AMOUNT
 - Change the minimumn amount of BNB spend to trigger a buy notification, default is 0.1 BNB.

/step STEP_AMOUNT
 - Change the 'step' amount, or how much BNB each dot represents. Default is 0.1 BNB (Eg: 1 BNB = 10 tree)

/emoji EMOJI
 - Change emoji, default is 🌳

/delete
 - Delete token notifications

Please note, I am a beta version. Errors, issues and omissions are possible!
Created by <b><a href="https://roburna.com">Roburna Labs</a></b> 
`;

bot.on("group_chat_created", async (ctx) => {
  console.log("group_chat_created");
  console.log(ctx);
  console.log(ctx.message);
});

bot.on("migrate_to_chat_id", handleMigrateToChatId);
bot.on("migrate_from_chat_id", handleMigrateFromChatId);
bot.on("new_chat_members", handleBotAdded);
bot.on("left_chat_member", handleBotKicked);

bot.start((ctx) => ctx.reply(helpMessage(ctx.botInfo), botOpts));
bot.help((ctx) => ctx.reply(helpMessage(ctx.botInfo), botOpts));

bot.command("add", groupCheck, isGroupAdmin, isGroupMaxTokenReached, addToken);
bot.command("delete", groupCheck, isGroupAdmin, deleteToken);
bot.command("emoji", groupCheck, isGroupAdmin, setEmoji);
bot.command("minbuy", groupCheck, isGroupAdmin, setMinBuy);
bot.command("step", groupCheck, isGroupAdmin, setStep);

bot.command("price", async (ctx) => {
  const rba_price_bnb = await getRoburnaPrice();
  const busd_price = await getBusdPrice();
  const totalSupply = await getTotalSupply();
  let message_reply = `
<b>Roburna Price :</b> 

1 RBA : $ ${formatNumber(rba_price_bnb * busd_price)}
1 RBA : ${formatNumber(rba_price_bnb, 8)} BNB

RBA Marketcap = $ ${getNumber(rba_price_bnb * busd_price * totalSupply)}

`;
  ctx.reply(message_reply, botOpts);
  return;
});

bot.command("info", async (ctx) => {
  let message_reply = `
<b>About Roburna</b> 

Website : https://roburna.com/
Telegram : https://t.me/Roburna
Twitter : https://twitter.com/Roburnaofficial
Whitepaper : <a href ="https://roburna.com/document/whitepaper_Roburna.pdf"> Download Here</a>

Token : <a href ="https://bscscan.com/token/0x72a80de6cb2c99d39139ef789c1f5e78a70345ab">View on BSCSCAN</a>
Buy Link : <a href ="https://pancakeswap.finance/swap?outputCurrency=0x72a80de6cb2c99d39139ef789c1f5e78a70345ab"> Pancakeswap</a>
`;
  ctx.reply(message_reply, botOpts);
  return;
});

bot.launch();

// Enable graceful stop
process.once("SIGINT", () => bot.stop("SIGINT"));
process.once("SIGTERM", () => bot.stop("SIGTERM"));
