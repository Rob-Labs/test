# [@RoburnaLabs_bot](https://t.me/RoburnaLabs_bot) Telegram bot code

# Installation

## local development

1. Clone this repo: `git clone https://github.com/wongjapan/roburna-labs-bot`
2. Install the [mongo database](https://www.mongodb.com/)
3. Create `.env` with the environment variables listed below
4. Run `yarn install` in the root folder
5. Run `yarn start-dev` in the root folder to start bot
6. Run `yarn listen-dev` in the root folder to start swap event listener

## production

1. Clone this repo: `git clone https://github.com/wongjapan/roburna-labs-bot`
2. Install the [mongo database](https://www.mongodb.com/)
3. Create `.env` with the environment variables listed below
4. Run `yarn install` in the root folder
5. Run `yarn start` in the root folder to start bot
6. Run `yarn stop` in the root folder to stop bot

And you should be good to go! Feel free to fork and submit pull requests. Thanks!

## Environment variables

- `BOT_TOKEN` — Telegram bot token
- `BOT_NAME` — Name of your bot
- `MONGODB_URL`— URL of the mongo database
- `WSS` — URL Websocket endpoint to blockchain node
- `RPC` — URL JSON-RPC endpoint to blockchain node

Also, please, consider looking at `.env.sample`.
