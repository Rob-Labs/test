module.exports = {
  apps: [
    {
      script: "index.js",
    },
    {
      script: "./src/listener.js",
      watch: ".",
    },
  ],
};
