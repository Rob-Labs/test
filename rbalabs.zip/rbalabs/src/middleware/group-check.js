const { notGroupChat, notGroupAdmin, maxGroupTokenLimitExceed } = require("../configs/messages/error");
const { default: mongoose } = require("mongoose");
const Tokens = mongoose.model("Tokens");
const Groups = mongoose.model("Groups");

const botOpts = {
  parse_mode: "HTML",
  disable_web_page_preview: true,
};

async function groupCheck(ctx, next) {
  if (ctx.chat.type == "private" || ctx.chat.type == "channel") {
    ctx.reply(notGroupChat);
    return;
  }
  // if (ctx.chat.username != "Roburna" && ctx.chat.username != "a5216554dfghfghfd") {
  //   ctx.reply(`Sorry, this bot currently supported <a href="https://t.me/Roburna">Roburna</a> only`, botOpts);
  //   return;
  // }
  return next();
}

async function isGroupAdmin(ctx, next) {
  if (typeof ctx.message == "undefined") {
    return;
  }

  if (ctx.message.text) {
    if (ctx.message.text.startsWith("/")) {
      let allowed = ["creator", "administrator"];
      let member = await ctx.telegram.getChatMember(ctx.chat.id, ctx.from.id);
      if (allowed.includes(member.status)) {
        return next();
      } else {
        ctx.reply(notGroupAdmin);
        return;
      }
    }
  }
}

async function isGroupMaxTokenReached(ctx, next) {
  const res = await Tokens.find({ groupId: ctx.chat.id });
  if (res.length > 0) {
    ctx.reply(maxGroupTokenLimitExceed, botOpts);
    return;
  }
  return next();
}

module.exports = {
  groupCheck,
  isGroupAdmin,
  isGroupMaxTokenReached,
};
