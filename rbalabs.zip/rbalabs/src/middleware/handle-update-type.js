const { default: mongoose } = require("mongoose");
const Tokens = mongoose.model("Tokens");
const Groups = mongoose.model("Groups");

const handleMigrateToChatId = async (ctx) => {
  console.log(ctx.message);
  try {
    await Tokens.find({ groupId: ctx.chat.id }).updateOne({ groupId: ctx.message.migrate_to_chat_id });
  } catch (error) {
    console.error(error);
  }
};

const handleMigrateFromChatId = async (ctx) => {
  console.log(ctx.message);
  try {
    await Tokens.find({ groupId: ctx.chat.id }).updateOne({ groupId: ctx.message.migrate_from_chat_id });
  } catch (error) {
    console.error(error);
  }
};

const handleBotAdded = async (ctx) => {
  if (ctx.message.new_chat_members[0].id == ctx.botInfo.id) {
    try {
      await Groups.create(ctx.chat);
    } catch (error) {
      console.log(error);
    }
  }
};

const handleBotKicked = async (ctx) => {
  if (ctx.message.left_chat_member.id == ctx.botInfo.id) {
    await Tokens.deleteOne({ groupId: ctx.chat.id });
  }
};

module.exports = {
  handleBotKicked,
  handleMigrateFromChatId,
  handleMigrateToChatId,
  handleBotAdded,
};
