const fs = require("fs");
const { tokenNotFound } = require("../configs/messages/error");
const { getPairToken } = require("../helpers/get-pair");
const { getTokenDetail } = require("../helpers/parse-token");
const { isValidAddress, restartListener } = require("../helpers/utils");
const { default: mongoose } = require("mongoose");
const Tokens = mongoose.model("Tokens");

const addToken = async (ctx) => {
  let address = ctx.message.text.split(" ");

  let insert_data = {
    groupId: "",
    tokenName: "",
    tokenAddress: "",
    tokenSymbols: "",
    tokenDecimals: 0,
    tokenPairs: 0,
    tokenIndex: 0,
    paused: false,
    minBuy: "0.1",
    step: "0.1",
    enableSell: true,
    emoji: "🌳",
  };

  const groupId = ctx.chat.id;

  if (address.length == 1) {
    ctx.reply("Please input BSC Token Address");
    return;
  }

  let token_address = address[1];
  if (!isValidAddress(token_address)) {
    ctx.reply(tokenNotFound);
    return;
  }

  // get pair
  let token_info = await getTokenDetail(token_address);
  if (!token_info) {
    ctx.reply(tokenNotFound);
    return;
  }
  // create variable
  const { tokenName, tokenDecimals, tokenSymbols } = token_info;
  // parse contract pair token : bnb
  const { pair, tokenIndex } = getPairToken(token_address);

  // check tokenA tokenB

  insert_data.groupId = groupId;
  insert_data.tokenAddress = token_address;
  insert_data.tokenDecimals = tokenDecimals;
  insert_data.tokenName = tokenName;
  insert_data.tokenIndex = tokenIndex;
  insert_data.tokenPairs = pair;
  insert_data.tokenSymbols = tokenSymbols;

  try {
    const res = await Tokens.create(insert_data);
    if (res) {
      restartListener();
      ctx.reply(`${tokenName} successfully added`);
    }
  } catch (error) {
    if (error.message.includes("E11000 duplicate key error")) {
      console.log(`WARN : token already recorded`);
      ctx.reply(`${tokenName} already inserted`);
    } else {
      ctx.reply(`Something wrong with server`);
      console.log(error);
    }
  }
};

module.exports = { addToken };
