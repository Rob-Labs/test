const { tokenNotFound } = require("../configs/messages/error");
const { isValidAddress, isFloat, isInt } = require("../helpers/utils");
const { default: mongoose } = require("mongoose");
const Tokens = mongoose.model("Tokens");
const botOpts = {
  parse_mode: "HTML",
  disable_web_page_preview: true,
};
const setPaused = async (ctx) => {
  let args = ctx.message.text.split(" ");

  const groupId = ctx.chat.id;

  if (args.length < 3) {
    ctx.reply(`Please input valid command : \n <pre>/set_paused token_address (true/false) </pre>`, botOpts);
    return;
  }

  let token_address = args[1];
  if (!isValidAddress(token_address)) {
    ctx.reply(tokenNotFound);
    return;
  }
  let newStatus = args[2];
  let validStatus = ["true", "false"];

  if (!validStatus.includes(newStatus)) {
    ctx.reply(`Please input valid command : \n <pre>/set_paused token_address (true/false) </pre>`, botOpts);
    return;
  }

  const edit_tokens = await Tokens.find({ groupId: groupId, tokenAddress: token_address });
  if (edit_tokens.length == 1) {
    try {
      const res = await Tokens.find({ groupId: groupId, tokenAddress: token_address }).updateOne({
        paused: newStatus,
      });
      if (res) ctx.reply(`${edit_tokens[0].tokenName} successfully updated`);
    } catch (error) {
      ctx.reply(`error when updating ${edit_tokens[0].tokenName}`);
    }
  }
  console.log(edit_tokens);
};

module.exports = { setPaused };
