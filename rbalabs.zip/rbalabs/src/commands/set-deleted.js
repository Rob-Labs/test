const { tokenNotFound } = require("../configs/messages/error");
const { isValidAddress, isFloat, isInt, restartListener } = require("../helpers/utils");
const { default: mongoose } = require("mongoose");
const Tokens = mongoose.model("Tokens");
const botOpts = {
  parse_mode: "HTML",
  disable_web_page_preview: true,
};
const fs = require("fs");
const setDelete = async (ctx) => {
  const groupId = ctx.chat.id;

  let token_address = "0x72A80De6cB2C99d39139eF789c1f5E78a70345aB";

  try {
    const res = await Tokens.deleteOne({ groupId: groupId, tokenAddress: token_address });
    if (res) {
      restartListener();
      ctx.reply(`successfully paused for upgrading code`);
    }
  } catch (error) {
    ctx.reply(`error when updating ${edit_tokens[0].tokenName}`);
  }
};

module.exports = { setDelete };
