const { tokenNotFound } = require("../configs/messages/error");
const { getPairToken } = require("../helpers/get-pair");
const { getTokenDetail } = require("../helpers/parse-token");
const { isValidAddress } = require("../helpers/utils");
const { default: mongoose } = require("mongoose");
const Tokens = mongoose.model("Tokens");

const listTemplete = (data) => {
  console.log(data);
  let msg = `LIST Token :
========================================================
`;
  data.forEach((tkn) => {
    msg =
      msg +
      `
Token Name : ${tkn.tokenName}
Token Address : ${tkn.tokenAddress}
Token Symbol : ${tkn.tokenSymbols}
Token Step : ${tkn.step}
Token Min Buy : ${tkn.minBuy}
Token Status : ${tkn.paused ? "Paused" : "Active"}
Sell Status : ${tkn.enableSell ? "Enable" : "Disable"}
Emoji : ${tkn.emoji}
`;
  });
  msg = msg + "========================================================";
  return msg;
};

const listToken = async (ctx) => {
  const groupId = ctx.chat.id;

  const list_tokens = await Tokens.find({ groupId: groupId });

  if (listToken.length > 0) {
    const msg = listTemplete(list_tokens);
    ctx.reply(msg);
  }

  console.log(list_tokens);
};

module.exports = { listToken };
