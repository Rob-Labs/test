const { tokenNotFound } = require("../configs/messages/error");
const { isValidAddress, isFloat, isInt, restartListener } = require("../helpers/utils");
const { default: mongoose } = require("mongoose");
const Tokens = mongoose.model("Tokens");
const botOpts = {
  parse_mode: "HTML",
  disable_web_page_preview: true,
};

const deleteToken = async (ctx) => {
  const groupId = ctx.chat.id;
  try {
    const res = await Tokens.deleteOne({ groupId: groupId });
    if (res) {
      ctx.reply(`successfully deactivate ${ctx.botInfo.first_name} Bot notification`);
    }
  } catch (error) {
    ctx.reply(`error when deactivate`);
    console.log(error);
  }
  restartListener();
  return;
};

module.exports = { deleteToken };
