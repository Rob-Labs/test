const { tokenNotFound } = require("../configs/messages/error");
const { getPair, getPairToken } = require("../helpers/get-pair");
const { getTokenDetail } = require("../helpers/parse-token");
const { isValidAddress, isFloat, isInt, isEmoji } = require("../helpers/utils");
const { default: mongoose } = require("mongoose");
const Tokens = mongoose.model("Tokens");
const botOpts = {
  parse_mode: "HTML",
  disable_web_page_preview: true,
};
const setEmoji = async (ctx) => {
  let args = ctx.message.text.split(" ");

  const groupId = ctx.chat.id;

  if (args.length < 2) {
    ctx.reply(`Please input valid command : \n<pre>/emoji emoji</pre>\n\n ex. <b>/emoji 🌳</b>`, botOpts);
    return;
  }

  let newEmoji = args[1];
  if (!isEmoji(newEmoji)) {
    ctx.reply(`Please input valid command : \n<pre>/emoji emoji</pre>\n\n ex. <b>/emoji 🌳</b>`, botOpts);
    return;
  }

  const edit_tokens = await Tokens.find({ groupId: groupId });
  if (edit_tokens.length == 1) {
    try {
      const res = await Tokens.find({ groupId: groupId }).updateOne({
        emoji: newEmoji,
      });
      if (res) ctx.reply(`${edit_tokens[0].tokenName} successfully updated`);
    } catch (error) {
      ctx.reply(`error when updating ${edit_tokens[0].tokenName}`);
    }
  }
};

module.exports = { setEmoji };
