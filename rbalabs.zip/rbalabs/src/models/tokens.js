const mongoose = require("mongoose");

const tokenSchema = new mongoose.Schema({
  groupId: String,
  tokenName: String,
  tokenAddress: String,
  tokenSymbols: String,
  tokenDecimals: Number,
  tokenPairs: String,
  tokenIndex: Number,
  paused: Boolean,
  minBuy: String,
  step: String,
  enableSell: Boolean,
  emoji: String,
});
tokenSchema.index({ groupId: 1, tokenAddress: 1 }, { unique: true });

module.exports = mongoose.model("Tokens", tokenSchema);
