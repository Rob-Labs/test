const mongoose = require("mongoose");

const groupSchema = new mongoose.Schema({
  id: Number,
  title: String,
  username: String,
  type: String,
});
groupSchema.index({ id: 1 }, { unique: true });

module.exports = mongoose.model("Groups", groupSchema);
