notGroupChat = "Sorry, this bot only for group chat";
notGroupAdmin = "Sorry, this function only respond for admin";
maxTokenLimitExceed = "Sorry, you have exceeded the maximum limit for adding tokens";
maxGroupTokenLimitExceed = "Sorry, this group have exceeded the maximum limit for adding tokens";
tokenNotFound = "Sorry, token not found";
tokenAlreadyAdd = "Sorry, token already added";
groupMemberNotReachMinimum = "Sorry, minimum group member required";

module.exports = {
  notGroupAdmin,
  notGroupChat,
  maxTokenLimitExceed,
  tokenAlreadyAdd,
  tokenNotFound,
  groupMemberNotReachMinimum,
  maxGroupTokenLimitExceed,
};
