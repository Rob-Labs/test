require("dotenv").config();

const helpMessage = `
Hi! I'm ${process.env.BOT_NAME} Bot, and these are the commands I respond too (Admins only!):

/add_token TOKEN_ADDRESS
 - Add the the token you want me to follow (max 3 per channel, must be a Pancakeswap WBNB Pair (eg: not BUSD/USDC).

Changing Settings
/change_min_buy TOKEN_ADDRESS MINIMUM_BUY_AMOUNT
 - Change the minimumn amount of BNB spend to trigger a buy notification, default is 0.1 BNB.

/change_step TOKEN_ADDRESS STEP_AMOUNT
 - Change the 'step' amount, or how much BNB each dot represents. Default is 0.1 BNB (Eg: 1 BNB = 10 tree)

Pause or Unpausing
/pause TOKEN_ADDRESS
 - Pause buy notifications for a certain token

/unpause TOKEN_ADDRESS
 - Unpause paused buy notifications for a certain token

Getting Details ${process.env.BOT_NAME} has for a group
/details
 - Returns settings/details for this group

/delete TOKEN_ADDRESS
 - Delete notifications for this token from this group

/disable_sell TOKEN_ADDRESS
 - Disable SELL notifications for this token from this group

/enable_sell TOKEN_ADDRESS
 - Enable SELL notifications for this token from this group

Help
/help
 - Repeat this message

Get ${process.env.BOT_NAME} Bot

Please note, I am a beta version. Errors, issues and omissions are possible!
I am free to use, but will at some point in the future display small text advertisments at the bottom of my posts.
 Thank you!
`;

module.exports = {
  helpMessage,
};
