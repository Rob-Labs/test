require("dotenv").config();
const emoji = require("node-emoji");
const { Telegraf } = require("telegraf");
const { formatNumber, nFormatter } = require("../helpers/get-number");
const { getRoburnaPrice, getBusdPrice, getTotalSupply, getRoburnaPool, getTokenPrice, getTokenTotalSupply } = require("../helpers/get-price");
const { parseSwapLogs } = require("./parse-logs");
const { restartListener } = require("./utils");
const { default: mongoose } = require("mongoose");
const Tokens = mongoose.model("Tokens");

const bot = new Telegraf(process.env.BOT_TOKEN);
const botOpts = {
  parse_mode: "HTML",
  disable_web_page_preview: true,
};

async function buildMessage(data) {
  let firstIcon = emoji.get("fire");
  let heartIcon = data.emoji;

  let buy = `<a href='https://app.bogged.finance/bsc/swap?tokenIn=0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c&tokenOut=${data.tokenAddress}'>Buy</a>`;
  let chart = `<a href='https://charts.bogged.finance/?c=bsc&t=${data.tokenAddress}'>Chart</a>`;
  let txHash = `<a href='https://bscscan.com/tx/${data.txHash}'>TX HASH</a>`;
  let buyer = `<a href='https://bscscan.com/address/${data.to}'>Buyer</a>`;

  if (data.orderType == "Sell") {
    firstIcon = emoji.get("red_circle");
    heartIcon = emoji.get("broken_heart");
  }

  // token rate calculation
  let bVal = data.pairValue / 1e18;
  let tVal = data.tokenValue / Math.pow(10, data.tokenDecimals);

  let tbRate = bVal / tVal;

  let buval = bVal * data.bnbprice;
  let tuRate = tbRate * data.bnbprice;

  const totalSupply = await getTokenTotalSupply(data.tokenAddress, data.tokenDecimals);

  let mcap = `$ ${nFormatter(tuRate * totalSupply)}`;

  let emoRepeat = Math.floor(bVal / data.step);

  if (data.orderType == "Sell") {
    return `
${firstIcon} <b>${data.tokenName} ${data.orderType}</b> ${firstIcon}

${heartIcon.repeat(emoRepeat)}

Spent : ${formatNumber(tVal, 8)} ${data.tokenSymbols}
Got : ${formatNumber(bVal)} BNB ($${formatNumber(buval, 2)})
DEX : Pancakeswap
Price : ${formatNumber(tbRate)} BNB ($${formatNumber(tuRate, 6)})
MCAP : ${mcap}

${txHash} | ${buy} | ${chart}

`;
  } else {
    return `
${firstIcon} <b>${data.tokenName}  ${data.orderType}</b> ${firstIcon}

${heartIcon.repeat(emoRepeat)}

Spent : ${formatNumber(bVal)} BNB ($${formatNumber(buval, 2)})
Got : ${formatNumber(tVal, 8)} ${data.tokenSymbols}
DEX : Pancakeswap
Price : ${formatNumber(tbRate)} BNB ($${formatNumber(tuRate, 6)})
MCAP : ${mcap}
${txHash} | ${buy} | ${chart}

Created by <a href="https://roburna.com">Roburna Labs</a>
`;
  }
}

async function broadcastBuy(data) {
  let result = {};
  let logData = parseSwapLogs(data);
  let token_info = await Tokens.find({ tokenPairs: logData.tokenPairs.toLowerCase() });

  if (logData.sender == logData.to) {
    console.log(`Router Routing`);
    return;
  }

  for (let i = 0; i < token_info.length; i++) {
    result = { ...token_info[i]._doc };
    result.txHash = logData.txHash;
    result.sender = logData.sender;
    result.to = logData.to;
    result.orderType = "Sell";
    result.tokenValue = logData.amount0In;
    result.pairValue = logData.amount1Out;

    if (logData.amount1Out < 10) {
      result.orderType = "Buy";
      result.tokenValue = logData.amount0Out;
      result.pairValue = logData.amount1In;
    }

    if (result.tokenIndex == 1) {
      orderType = "Sell";
      result.tokenValue = logData.amount0Out;
      result.pairValue = logData.amount1In;

      if (logData[3] < 10) {
        result.orderType = "Buy";
        result.tokenValue = logData.amount0In;
        result.pairValue = logData.amount1Out;
      }
    }
    if (result.orderType == "Sell") {
      console.log("SELL Orders Not Processed");
      return;
    }
    let bVal = result.pairValue / 1e18;
    if (bVal < result.minBuy) {
      console.log("minimum buy not reached " + bVal);
    } else {
      const bnbprice = await getBusdPrice();
      result.bnbprice = bnbprice;
      let tgMessage = await buildMessage(result);
      try {
        await bot.telegram.sendMessage(Number(result.groupId), tgMessage, botOpts);
      } catch (error) {
        if (error.response.description.includes("bot was kicked")) {
          await Tokens.deleteOne({ groupId: result.groupId });
          restartListener();
          console.log(`Successfully delete group notification`);
        }
        if (error.response.description.includes("upgraded to a supergroup chat")) {
          await Tokens.deleteOne({ groupId: result.groupId });
          restartListener();
        }
        console.log(error.response.description);
        console.log(`Bot is kicked`);
      }
    }
  }
}

module.exports = broadcastBuy;
