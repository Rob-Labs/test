require("dotenv").config();
const emoji = require("node-emoji");
const { Telegraf } = require("telegraf");
const { MIN_BUY, DISABLE_SELL, ROBURNA_ADDRESS, ROBURNA_PAIR, EMOJI_STEP, EMPIRE_CHANNEL } = require("../configs/constants");
const { formatNumber, getNumber, nFormatter } = require("../helpers/get-number");
const { getRoburnaPrice, getBusdPrice, getTotalSupply, getRoburnaPool } = require("../helpers/get-price");

const bot = new Telegraf(process.env.PAIR_BOT_TOKEN);
const botOpts = {
  parse_mode: "HTML",
  disable_web_page_preview: true,
};

async function buildMessage(orderType, tValue, bValue, data, bnbprice) {
  let firstIcon = emoji.get("fire");
  let heartIcon = emoji.get("deciduous_tree");
  // https://pancakeswap.finance/swap?outputCurrency=0x72a80de6cb2c99d39139ef789c1f5e78a70345ab
  let buy = `<a href='https://app.bogged.finance/bsc/swap?tokenIn=0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c&tokenOut=${ROBURNA_ADDRESS}'>Buy</a>`;
  let chart = `<a href='https://charts.bogged.finance/?c=bsc&t=${ROBURNA_ADDRESS}'>Chart</a>`;
  let txHash = `<a href='https://bscscan.com/tx/${data.transactionHash}'>TX HASH</a>`;

  if (orderType == "Sold") {
    firstIcon = emoji.get("red_circle");
    heartIcon = emoji.get("broken_heart");
  }
  const rba_price_bnb = await getRoburnaPrice();
  const totalSupply = await getTotalSupply();
  const [roburna_pool, wbnb_pool] = await getRoburnaPool();

  let mcap = `$ ${nFormatter(rba_price_bnb * bnbprice * totalSupply)}`;

  // token rate calculation
  let bVal = bValue / 1e18;
  let tVal = tValue / 1e18;

  let tbRate = bVal / tVal;
  let btRate = tVal / bVal;

  let buval = bVal * bnbprice;
  let tuRate = tbRate * bnbprice;

  let emoRepeat = Math.ceil(bVal / EMOJI_STEP);

  if (orderType == "Sold") {
    return `
${firstIcon} <b>Roburna (RBA) ${orderType}</b> ${firstIcon}

${heartIcon.repeat(emoRepeat)}
<pre>
Spent   : ${formatNumber(tVal, 8)} RBA
Got     : ${formatNumber(bVal)} BNB ($${formatNumber(buval, 2)})
DEX     : Pancakeswap
Price   : ${formatNumber(tbRate)} BNB ($${formatNumber(tuRate, 6)})
MCAP    : ${mcap}
POOL    : ${nFormatter(roburna_pool / 1e18)} RBA : ${nFormatter(wbnb_pool / 1e18)} BNB
</pre>
📶 ${txHash} | ${emoji.get("heavy_dollar_sign")} ${buy} | ${emoji.get("chart")} ${chart}

`;
  } else {
    return `
${firstIcon} <b>Roburna (RBA) ${orderType}</b> ${firstIcon}

${heartIcon.repeat(emoRepeat)}
<pre>
Spent   : ${formatNumber(bVal)} BNB ($${formatNumber(buval, 2)})
Got     : ${formatNumber(tVal, 8)} RBA
DEX     : Pancakeswap
Price   : ${formatNumber(tbRate)} BNB ($${formatNumber(tuRate, 6)})
MCAP    : ${mcap}
POOL    : ${nFormatter(roburna_pool / 1e18)} RBA : ${nFormatter(wbnb_pool / 1e18)} BNB
</pre>
📶 ${txHash} | ${emoji.get("heavy_dollar_sign")} ${buy} | ${emoji.get("chart")} ${chart}

`;
  }
}

async function parseLogData(data) {
  let logData = data.returnValues;
  if (logData.sender == logData.to) {
    console.log(`Router Routing`);
    return;
  }

  let orderType = "Sold";
  let tValue = logData.amount0In;
  let bValue = logData.amount1Out;

  if (logData.amount1Out < 10) {
    orderType = "Bought";
    tValue = logData.amount0Out;
    bValue = logData.amount1In;
  }

  if (orderType == "Sold" && DISABLE_SELL) {
    console.log("SELL Orders Not Processed");
    return;
  }

  const bnbprice = await getBusdPrice();

  let bVal = bValue / 1e18;
  if (bVal < MIN_BUY) {
    console.log("minimum buy tidak tercapai " + bVal);
  } else {
    let tgMessage = await buildMessage(orderType, tValue, bValue, data, bnbprice);
    // console.log(tgMessage);
    bot.telegram.sendMessage(EMPIRE_CHANNEL, tgMessage, botOpts);
  }
}

module.exports = parseLogData;
