const { web3rpc } = require("./get-web3");
const erc20Abi = require("../abi/erc20.json");

async function getTokenDetail(token) {
  const erc20Contract = new web3rpc.eth.Contract(erc20Abi, token);

  try {
    const [totalSupply, tokenName, tokenDecimals, tokenSymbols] = await Promise.all([
      erc20Contract.methods.totalSupply().call(),
      erc20Contract.methods.name().call(),
      erc20Contract.methods.decimals().call(),
      erc20Contract.methods.symbol().call(),
    ]);

    return { totalSupply, tokenName, tokenDecimals, tokenSymbols };
  } catch (error) {
    return false;
  }
}

module.exports = {
  getTokenDetail,
};
