const Web3EthAbi = require("web3-eth-abi");
const swapEvents = require("../abi/swap.json");

const parseSwapLogs = (log) => {
  const topics = [log.topics[1], log.topics[2]];
  let returned = Web3EthAbi.decodeLog(swapEvents, log.data, topics);
  returned.tokenPairs = log.address;
  returned.txHash = log.transactionHash;
  return returned;
};

module.exports = {
  parseSwapLogs,
};
