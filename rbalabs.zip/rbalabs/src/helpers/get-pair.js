const { FACTORY_ADDRESS, INIT_CODE_PAIR_HASH, WBNB_ADDRESS } = require("../configs/constants");
const Web3 = require("web3");
const web3 = new Web3();
function getPair(tokenB) {
  let tokenA = WBNB_ADDRESS;
  let _hexadem = INIT_CODE_PAIR_HASH;
  let _factory = FACTORY_ADDRESS;
  let [token0, token1] = tokenA < tokenB ? [tokenA, tokenB] : [tokenB, tokenA];

  let abiEncoded1 = web3.eth.abi.encodeParameters(["address", "address"], [token0, token1]);
  abiEncoded1 = abiEncoded1.split("0".repeat(24)).join("");
  let salt = web3.utils.soliditySha3(abiEncoded1);
  let abiEncoded2 = web3.eth.abi.encodeParameters(["address", "bytes32"], [_factory, salt]);
  abiEncoded2 = abiEncoded2.split("0".repeat(24)).join("").substr(2);
  let pair = "0x" + Web3.utils.soliditySha3("0xff" + abiEncoded2, _hexadem).substr(26);
  return pair;
}

function getPairToken(tokenB) {
  let tokenA = WBNB_ADDRESS;
  let _hexadem = INIT_CODE_PAIR_HASH;
  let _factory = FACTORY_ADDRESS;
  let [token0, token1] = tokenA < tokenB ? [tokenA, tokenB] : [tokenB, tokenA];

  let abiEncoded1 = web3.eth.abi.encodeParameters(["address", "address"], [token0, token1]);
  abiEncoded1 = abiEncoded1.split("0".repeat(24)).join("");
  let salt = web3.utils.soliditySha3(abiEncoded1);
  let abiEncoded2 = web3.eth.abi.encodeParameters(["address", "bytes32"], [_factory, salt]);
  abiEncoded2 = abiEncoded2.split("0".repeat(24)).join("").substr(2);
  let pair = "0x" + Web3.utils.soliditySha3("0xff" + abiEncoded2, _hexadem).substr(26);

  let tokenIndex = tokenB == token0 ? 0 : 1;
  return { pair, tokenIndex };
}

module.exports = { getPair, getPairToken };
