const { ROBURNA_ADDRESS, BUSD_PAIR_ADDRESS } = require("../configs/constants");
const { getPair } = require("../helpers/get-pair");
const { web3rpc } = require("../helpers/get-web3");

const pairAbi = require("../abi/pair.json");
const ercAbi = require("../abi/erc20.json");

roburnaContract = new web3rpc.eth.Contract(ercAbi, ROBURNA_ADDRESS);

const roburna_pair = getPair(ROBURNA_ADDRESS);
const pairContract = new web3rpc.eth.Contract(pairAbi, roburna_pair);
const busdPairContract = new web3rpc.eth.Contract(pairAbi, BUSD_PAIR_ADDRESS);

async function getRoburnaPrice() {
  const reserves = await pairContract.methods.getReserves().call();
  const [roburna, wbnb] = [reserves[0], reserves[1]];
  return wbnb / roburna;
}

async function getTokenPrice(pair_address, token_index) {
  const tokenContract = new web3rpc.eth.Contract(pairAbi, pair_address);
  const reserves = await tokenContract.methods.getReserves().call();
  const [token, wbnb] = token_index == 0 ? [reserves[0], reserves[1]] : [reserves[1], reserves[0]];

  return wbnb / token;
}

async function getRoburnaPool() {
  const reserves = await pairContract.methods.getReserves().call();
  return [reserves[0], reserves[1]];
}

async function getBusdPrice() {
  const reserves = await busdPairContract.methods.getReserves().call();
  const [wbnb, busd] = [reserves[0], reserves[1]];
  return busd / wbnb;
}

async function getTotalSupply() {
  const totalSupply = await roburnaContract.methods.totalSupply().call();
  return totalSupply / 1e18;
}

async function getTokenTotalSupply(token_address, token_decimals) {
  const tokenContract = new web3rpc.eth.Contract(ercAbi, token_address);
  const totalSupply = await tokenContract.methods.totalSupply().call();
  return totalSupply / Math.pow(10, token_decimals);
}

module.exports = {
  getBusdPrice,
  getRoburnaPrice,
  getTotalSupply,
  getRoburnaPool,
  getTokenPrice,
  getTokenTotalSupply,
};
