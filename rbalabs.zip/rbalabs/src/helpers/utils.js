// const { web3rpc } = require("./get-web3");
require("dotenv").config();
const { exec } = require("child_process");
const fs = require("fs");
const web3 = require("web3");

const isValidAddress = (addr) => {
  return web3.utils.isAddress(addr);
};

function isFloat(n) {
  return Number(n) === n && n % 1 !== 0;
}

function isInt(n) {
  return Number(n) === n && n % 1 === 0;
}

function restartListener() {
  if (process.env.NODE_ENV == "production") {
    exec("pm2 restart listener");
  } else {
    fs.writeFileSync(`${__dirname}/../gc/${Date.now()}.json`, "deleted", (err) => {});
  }
  return;
}

function isEmoji(data) {
  const regex = /\p{Extended_Pictographic}/gu;
  return regex.test(data); // true, as expected
}

module.exports = {
  isValidAddress,
  isFloat,
  isInt,
  restartListener,
  isEmoji,
};
