const Web3 = require("web3");
require("dotenv").config();

const options = {
  timeout: 30000, // ms
  clientConfig: {
    keepalive: true,
    keepaliveInterval: 60000, // ms
  },
  // Enable auto reconnection
  reconnect: {
    auto: true,
    delay: 5000, // ms
    maxAttempts: 5,
    onTimeout: true,
  },
};
const web3socket = new Web3(process.env.WSS, options);
const web3rpc = new Web3(process.env.RPC);

module.exports = {
  web3rpc,
  web3socket,
};
