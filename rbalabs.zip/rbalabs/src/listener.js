const { web3socket } = require("./helpers/get-web3");
require("./models/db");
const { default: mongoose } = require("mongoose");
const Tokens = mongoose.model("Tokens");

const broadcastBuy = require("./helpers/broadcast-buy");

Tokens.distinct("tokenPairs", {}, function (err, result) {
  if (err) {
    console.log(`Error Occured`);
    throw err;
  }
  console.log(result);
  if (result.length > 0) {
    const subscription = web3socket.eth
      .subscribe("logs", {
        address: result, // variable
        topics: ["0xd78ad95fa46c994b6551d0da85fc275fe613ce37657fb8d5e3d130840159d822"], // swap topic
      })
      .on("connected", function (subscriptionId) {
        console.log(`Listen to Swap events with subscriptionId : ${subscriptionId}`);
      })
      .on("error", function (error) {
        console.log(error);
        throw error;
      })
      .on("data", function (log) {
        broadcastBuy(log);
      });
  }
});
